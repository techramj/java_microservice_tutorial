
insert into book(id, name) values ('B99999','Test1');

