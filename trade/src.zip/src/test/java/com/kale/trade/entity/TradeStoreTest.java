package com.kale.trade.entity;

import static org.junit.jupiter.api.Assertions.*;

class TradeStoreTest {

}