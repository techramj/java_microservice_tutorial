package com.kale.trade.dao;

import com.kale.trade.entity.Trade;
import org.springframework.stereotype.Repository;

@Repository
public class TradeDao extends Dao<Trade>{
}
