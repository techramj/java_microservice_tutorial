package com.easylearning.patientproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
