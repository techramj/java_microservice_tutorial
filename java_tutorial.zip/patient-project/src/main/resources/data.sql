insert into patient(id,name) values (1,'Pawan');
insert into patient(id,name) values (2,'Satish');
insert into patient(id,name) values (3,'Indra');
insert into patient(id,name) values (4,'Abhijeet');