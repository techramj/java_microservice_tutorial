package com.easylearning.medicineproject.service;

import com.easylearning.medicineproject.bean.Medicine;
import com.easylearning.medicineproject.dao.MedicineDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicineService {

    @Autowired
    private MedicineDao medicineDao;

    public List<Medicine> fetchAllMedicine(){
       return medicineDao.findAll();
    }
}
