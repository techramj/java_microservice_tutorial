package com.easylearning.medicineproject.controller;


import com.easylearning.medicineproject.bean.Medicine;
import com.easylearning.medicineproject.service.MedicineService;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MedicineController {

    @Autowired
    private MedicineService medicineService;

    @GetMapping("/medicine")
    public MappingJacksonValue fetchAllMedicine(){
        List<Medicine> medicines = medicineService.fetchAllMedicine();
        SimpleBeanPropertyFilter filter= SimpleBeanPropertyFilter.serializeAll();

        FilterProvider filterProvider=new SimpleFilterProvider().addFilter("medicineFilter",filter);
        MappingJacksonValue mapping =  new MappingJacksonValue(medicines);

        mapping.setFilters(filterProvider);
        return mapping;
    }

    @GetMapping("/medicine1")
    public MappingJacksonValue fetchAllMedicine1(){
        List<Medicine> medicines = medicineService.fetchAllMedicine();
        SimpleBeanPropertyFilter filter= SimpleBeanPropertyFilter.filterOutAllExcept("id","name");

        FilterProvider filterProvider=new SimpleFilterProvider().addFilter("medicineFilter",filter);
        MappingJacksonValue mapping =  new MappingJacksonValue(medicines);

        mapping.setFilters(filterProvider);
        return mapping;
    }


}
