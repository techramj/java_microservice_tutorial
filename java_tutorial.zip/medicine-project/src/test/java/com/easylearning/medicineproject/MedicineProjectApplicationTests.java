package com.easylearning.medicineproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
